# Sony Alpha case study — GitHub Pages package

Upload this entire folder structure to your portfolio repository.

```text
sony-alpha.html
assets/
  sony/
    images/
      ...extracted case-study images...
```

From your homepage, link to the case study with:

```html
<a href="sony-alpha.html">Sony Alpha</a>
```

Do not rename or move the `assets/sony/images` folder unless you also update the paths inside `sony-alpha.html`.
